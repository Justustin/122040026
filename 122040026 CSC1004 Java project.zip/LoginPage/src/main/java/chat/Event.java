/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package chat;

/**
 *
 * @author Asus
 */
public class Event {


    private static Event instance;
    private ChatEvent eventChat;
    
    
    public static Event getInstance(){
        if (instance == null){
            instance = new Event();
        }
        return instance;
    }
    
    private Event(){
        
    }
    public void addChatEvent(ChatEvent event){
        this.eventChat = event;
    }
    public ChatEvent getChatEvent(){
        return eventChat;
    }

    
    
    
}
