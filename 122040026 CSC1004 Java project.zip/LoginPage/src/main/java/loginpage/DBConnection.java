/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginpage;
import java.sql.*;

/**
 *
 * @author Asus
 */
public class DBConnection {
   
    static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/register?allowPublicKeyRetrieval=true&useSSL=false&characterEncoding=utf-8";
    static final String USER = "root";
    static final String PASS = "Awdrgyjil1!";
    public static Connection connectDB(){
         Connection conn = null;
        try{
            conn = DriverManager.getConnection(DB_URL,USER,PASS);
            return conn; 
        }catch(Exception ex){
            ex.printStackTrace();
            System.out.println("There was an error while connecting to the server");
            return null;
        }
    }
    
}
