/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import java.io.*;
import java.net.*;
import java.util.*;

public class Server {
    private static ArrayList<ClientHandler> clients = new ArrayList<ClientHandler>();
    private static HashSet<String> usernames = new HashSet<String>();

    public void connect() throws IOException {
        ServerSocket server = new ServerSocket(8888);
        System.out.println("Server started on port 8888");

        while (true) {
            Socket client = server.accept();
            System.out.println("New client connected");

            ClientHandler newClient = new ClientHandler(client);
            clients.add(newClient);
            newClient.start();
        }
    }




class ClientHandler extends Thread {
    private String username;
    private Socket client;
    private DataInputStream input;
    private DataOutputStream output;

    public ClientHandler(Socket client) {
        this.client = client;
        try {
            input = new DataInputStream(client.getInputStream());
            output = new DataOutputStream(client.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    

    public void sendMessage(String message) {

}
}}